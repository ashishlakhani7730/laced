<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('m_user');
    }

    public function index() {
		if($this->session->userdata('Admin_Id'))
		{
			$data['user_list'] = $this->m_user->get_user();
			$this->load->view('show_user', $data);
		}
		else
		{
			redirect('login');
		}
    }

    public function add() {
		if($this->session->userdata('Admin_Id'))
		{
			$this->load->view('user_form');
		}
		else
		{
			redirect('login');
		}
    }

    public function addp() {
		if($this->session->userdata('Admin_Id'))
		{
			date_default_timezone_set("Asia/Kolkata");
			$created = date("Y-m-d H:i:s");

			$test = uniqFileNameGenerator($_FILES['upload']);
			$destinationPath = FCPATH . 'Items/' . $test;
			move_uploaded_file($_FILES['upload']['tmp_name'], $destinationPath);    



			$config['upload_path'] = './Items/';
			$config['allowed_types'] = 'gif|jpg|png|docx';
			$config['remove_spaces'] = TRUE;
			$config['overwrite'] = FALSE;
			$config['encrypt_name'] = TRUE;
			


			$this->load->library('upload', $config);
			$this->upload->initialize($config);

			
				$this->m_user->insert_data($_POST['User_Name'], $_POST['User_Email'], $_POST['User_Password'], $_POST['User_Address'], $_POST['User_Phone'], $test, $_POST['User_Latitude'], $_POST['User_Longitude'], $created);
				$this->session->set_flashdata('message', 'user added Successfully..');
				redirect("user/index");
		}
		else
		{
			redirect('login');
		}
    }

    public function editp() {
		if($this->session->userdata('Admin_Id'))
		{
			date_default_timezone_set("Asia/Kolkata");
			$modified = date("Y-m-d H:i:s");

        

			$test = uniqFileNameGenerator($_FILES['upload']);
			$destinationPath = FCPATH . 'Items/' . $test;
			move_uploaded_file($_FILES['upload']['tmp_name'], $destinationPath);    



			$config['upload_path'] = './Items/';
			$config['allowed_types'] = 'gif|jpg|png|docx';
			$config['remove_spaces'] = TRUE;
			$config['overwrite'] = FALSE;
			$config['encrypt_name'] = TRUE;
        


			$this->load->library('upload', $config);
			$this->upload->initialize($config);
        
            $this->m_user->update_data($_POST['User_Id'], $_POST['User_Name'], $_POST['User_Email'], $_POST['User_Password'], $_POST['User_Address'], $_POST['User_Phone'], $test, $modified);
            $this->session->set_flashdata('message', 'user edit Successfully..');
            redirect("user/index");
        }
		else
		{
			redirect('login');
		}
    }

    public function active_data($User_Id) {

		if($this->session->userdata('Admin_Id'))
		{
			$this->m_user->active_data($User_Id);
			$this->session->set_flashdata('message', 'active successfully...');
			redirect("user/index");
		}
		else
		{
			redirect('login');
		}
    }

    public function deactive_data($User_Id) {
		
		if($this->session->userdata('Admin_Id'))
		{
			$this->m_user->deactive_data($User_Id);
			$this->session->set_flashdata('message', 'deactive successfully...');
			redirect("user/index");
		}
		else
		{
			redirect('login');
		}
    }

    public function edit_data($User_Id) {
		if($this->session->userdata('Admin_Id'))
		{
			$data['update_data'] = $this->m_user->edit_data($User_Id);
			$this->load->view('user_form', $data);
		}
		else
		{
			redirect('login');
		}
    }

    public function delete_data($User_Id) {
		if($this->session->userdata('Admin_Id'))
		{
			$this->m_user->delete_data($User_Id);
			$this->session->set_flashdata('message', 'delete successfully...');
			redirect("user/index");
		}
		else
		{
			redirect('login');
		}
    }

    public function notification()
    {
    	if($this->session->userdata('Admin_Id'))
		{
	    	$status = intval(1);
	    	$zero = intval(0);

	    	$this->db->set('modified', 'NOW()', FALSE);
			$this->db->where('Admin_Id', $status);
			$this->db->where('Notification_Status', $zero);
			$this->db->update('notification',array('Notification_Status' => $status));

			if($this->db->affected_rows() > 0)
			{
				$response['code'] = 1;
			}
			else
			{
				$response['code'] = 0;
			}
			
			echo json_encode($response);
		}
		else
		{
			$response['code'] = 0;
		}
    }

    public function getverifyuserdetail()
    {
    	if($this->session->userdata('Admin_Id'))
		{

	    	$this->db->select("*");
	    	$this->db->from("auction_user_card_detail");
	    	$this->db->where("User_Id",$this->input->post('User_id'));

	    	$query = $this->db->get();

	    	$this->db->select("*");
	    	$this->db->from("auction_user_bank_info");
	    	$this->db->where("User_Id",$this->input->post('User_id'));

	    	$query2 = $this->db->get();

	    	//echo "<pre>"; print_r($query->result()); exit;

    		if($query->num_rows())
    		{
    			$response['code_credit'] = 1;
    			$response['creditcarddetail'] = 1;
    		}
    		else
    		{
    			$response['code_credit'] = 0;
    			$response['creditcarddetail'] = 0;
    		}

    		if($query2->num_rows())
    		{
    			$response['code_bank'] = 1;
    			$response['bankdetail'] = 1;
    		}
    		else
    		{
    			$response['code_bank'] = 0;
    			$response['bankdetail'] = 0;
    		}
			
			echo json_encode($response);
		}
		else
		{
			$response['code'] = 0;
		}
    }

    public function verifyuser()
    {
    	if($this->session->userdata('Admin_Id'))
		{
	    	$userid = intval($this->input->post('USERID'));
	    	$verified = intval(1);

	    	$this->db->set('modified', 'NOW()', FALSE);
			$this->db->where('User_Id', $userid);
			$this->db->update('auction_user',array('User_verified' => $verified));

			if($this->db->affected_rows() > 0)
			{
				$response['code'] = 1;
				$response['message'] = 'User verify successfully.';
			}
			else
			{
				$response['code'] = 0;
				$response['message'] = 'somthing went to wrong.';
			}
			
			echo json_encode($response);
		}
		else
		{
			$response['code'] = 0;
		}
    }

}
