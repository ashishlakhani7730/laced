<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Bid extends CI_Controller {
	
	public function __construct() {
        parent::__construct();

        //$this->load->model('m_bid');
    }
	
	public function index()
	{
		if($this->session->userdata('Admin_Id'))
		{
			$this->db->select("*");
			$this->db->from("auction_item");
			$this->db->where("Item_Id IN (SELECT DISTINCT Item_Id FROM auction_bid)", NULL, FALSE);
			//$this->db->join('auction_bid ab','ab.Item_Id = ai.Item_Id');
			
			$query = $this->db->get();
			$data['bidlist'] = $query->result();
			
			//echo "<pre>"; print_r($data['bidlist']); exit;
			
			$this->load->view('bid_item', $data);
		}
		else
		{
			redirect('login');
		}
	}
	
	public function bidlist()
	{
		$response = array();
		
		if($this->session->userdata('Admin_Id'))
		{
			$this->db->select("ab.Bid_Price,ab.Winner,au.User_ProfilePic, au.User_Name");
			$this->db->from("auction_bid ab");
			$this->db->join('auction_user au','ab.User_Id = au.User_Id');
			$this->db->where('ab.Item_Id',$this->input->post('item_id'));
			$this->db->order_by('ab.Bid_Price','DESC');
			
			$query = $this->db->get();
			$list = $query->result();
			
			
			if($list)
			{
				$response['code'] = 1;
				$response['datas'] = $list;
			}
			else
			{
				$response['code'] = 0;
				$response['message'] = "Please Try Again";
			}
			
			header('Content-Type: application/json');
			echo json_encode($response);
		}
		else
		{
			redirect('login');
		}
	}

}