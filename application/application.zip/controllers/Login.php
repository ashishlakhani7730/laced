<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('m_login');
    }

    public function index() {
        $this->load->view('login_view');
    }

    public function forgot() {
        $this->load->view('forgotpwd_view');
    }

    public function checkdata() {
        $check_value = $this->m_login->validate($_POST['Admin_Email'], md5($_POST['Admin_Password']));
        if (isset($check_value['Admin_Id'])) {
            $this->session->set_userdata('Admin_Id', $check_value['Admin_Id']);
            $this->session->set_userdata('Admin_Email', $check_value['Admin_Email']);
            $this->session->set_userdata('Admin_Name', $check_value['Admin_Name']);
            $this->session->set_userdata('Admin_Role', $check_value['Admin_Role']);
            $this->session->set_userdata('Admin_ProfilePic', $check_value['Admin_ProfilePic']);
            $this->session->set_userdata('Admin_Password', $check_value['Admin_Password']);
            $this->session->set_flashdata('message', 'login successfully');
            redirect("home/index");
        } else {
            $this->session->set_flashdata('message', 'Please Enter Valid Email and Password');
            redirect("login/index");
        }
    }

    public function forgotpass() {

      $Admin_Email = $this->input->post('Admin_Email');
      $newpassword = $this->input->post('newpassword');
      $cpassword = $this->input->post('cpassword');
      $check = $this->m_login->check_name($Admin_Email);

      if ($newpassword == $cpassword) {
      if (isset($check['Admin_Id'])) {

      $this->m_login->change_data($Admin_Email, $newpassword);
      $this->session->set_flashdata('message', 'pwd is changed');
      redirect("login/index");
      } else {

      $this->session->set_flashdata('message', 'enter valid username');
      redirect("login/forgot");
      }
      }
      $this->session->set_flashdata('message', 'pwd and confirmpwd is not same');
      redirect("login/forgot");
    } 

    public function logout() {
        $this->session->sess_destroy();
        redirect("login/index");
    }
}
