<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_contest extends CI_Model {

    public function get_raffle() {
        $id = 3;
        $type = intval($id);

        $this->db->select("c.*,ab.Brand_Name,ai.*");
        $this->db->from("contest c");
        $this->db->join("auction_item ai", "ai.Item_Id = c.Item_Id");
        $this->db->join("auction_brand ab", "ai.Brand_Id = ab.Brand_Id");
        $this->db->order_by("Contest_Id", "desc");

        $query = $this->db->get();

        return $query->result();
    }

    public function addcontestdate($data, $Contest_Id) {

        $this->db->where('Contest_Id', $Contest_Id);
        $this->db->update('contest', array("Start_Date" => $data['sdate'], "End_Date" => $data['edate'], "startdateampm" => $data['sdateampm'], "endddateampm" => $data['edateampm']));

        //print_r($this->db->last_query()); exit;
        return true;
    }

    public function setnotification($data) {
        $this->db->set('created', 'NOW()', FALSE);
        $this->db->insert('notification', array('User_Id' => $data['User_Id'], 'Item_Id' => $data['Item_Id'], 'Notification_Title' => $data['Notification_Title'], 'Notification_Type' => $data['Notification_Type'], 'Notification_Message' => $data['Notification_Message']));

        if ($data['Notification_Type'] != 'auction') {
            return true;
        }
    }

}
