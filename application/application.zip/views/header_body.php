<!-- Top Menu Items -->
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="mobile-only-brand pull-left">
        <div class="nav-header pull-left">
            <div class="logo-wrap">
                <a href="<?php echo base_url()."/home"; ?>">
                    <img class="brand-img" src="<?php echo base_url() ?>assets/dist/img/logo2.png" height="50" />
                    
                    
                </a>
            </div>
        </div>	
        <a id="toggle_nav_btn" class="toggle-left-nav-btn inline-block ml-20 pull-left" href="javascript:void(0);"><i class="zmdi zmdi-menu"></i></a>
        <a id="toggle_mobile_search" data-toggle="collapse" data-target="#search_form" class="mobile-only-view" href="javascript:void(0);"><i class="zmdi zmdi-search"></i></a>
        <a id="toggle_mobile_nav" class="mobile-only-view" href="javascript:void(0);"><i class="zmdi zmdi-more"></i></a>
        
    </div>
    <div id="mobile_only_nav" class="mobile-only-nav pull-right">
        <ul class="nav navbar-right top-nav pull-right">
            <?php 
                    $sql ="SELECT * FROM notification WHERE Admin_Id = 1 AND Notification_Status = 0 order by Notification_Id desc"; 
                    $que = $this->db->query($sql); 
                    $res = $que->result();
                   // echo "<pre>";print_r($que->result());

             ?>
                        <li class="dropdown alert-drp">
                            <a id="notify" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="zmdi zmdi-notifications top-nav-icon"></i><span class="top-nav-icon-badge"><?php echo $que->num_rows(); ?></span></a>
                            <ul  class="dropdown-menu alert-dropdown" data-dropdown-in="bounceIn" data-dropdown-out="bounceOut">
                                <li>
                                    <div class="streamline message-nicescroll-bar">
                                        <?php if(!empty($res)){ ?>
                                         <?php foreach($res as $r) {?>
                                        
                                        <div class="sl-item">
                                            <a href="javascript:void(0)">
                                                <div>
                                                    <p style="color:black"><?php echo $r->Notification_Message; ?></p>
                                                </div>
                                            </a>    
                                        </div>
                                        <hr class="light-grey-hr ma-0"/>
                                        <?php } } else { ?>
                                        <div class="sl-item">
                                            <a href="javascript:void(0)">
                                                <div>
                                                    <p style="color:black">Currently No Any Notification Found</p>
                                                </div>
                                            </a>    
                                        </div>
                                        <?php } ?>
                                    </div>
                                </li>
                                <li>
                                    <div class="notification-box-bottom-wrap">
                                        <hr class="light-grey-hr ma-0"/>
                                        <a class="block text-center read-all" href="<?php echo base_url()."viewnotifications"; ?>"> View all </a>
                                        <div class="clearfix"></div>
                                    </div>
                                </li>
                            </ul>
                        </li>
           
            <li class="dropdown auth-drp">
                <a href="#" class="dropdown-toggle pr-0" data-toggle="dropdown">
                    <?php 
                        $this->db->select("Admin_ProfilePic");
                        $this->db->from("auction_admin");
                        $this->db->where("Admin_Id","1");

                        $query = $this->db->get();

                        $data = $query->result();
                       //print_r($data[0]->Admin_ProfilePic);
                    ?>

                    <img src="<?php if($data[0]->Admin_ProfilePic) { echo base_url()."Items/".$data[0]->Admin_ProfilePic; } else { echo base_url()."/Items/2050919978818f175884327f0c5195706003ac66095b0fec6d18b23.png"; } ?>" alt="user_auth" class="user-auth-img img-circle"/></a>
                <ul class="dropdown-menu user-auth-dropdown" data-dropdown-in="flipInX" data-dropdown-out="flipOutX">
                    <?php
                    $Admin_Id=$this->session->userdata('Admin_Id');
                    ?>
                    <li>
                        <a href="<?php echo site_url("profile/edit_data/$Admin_Id"); ?>"><i class="zmdi zmdi-account"></i><span>Profile</span></a>
                    </li>
                    
                    
                    <li class="divider"></li>
                    <li>
                        <a href="<?php echo site_url("login/logout"); ?>"><i class="zmdi zmdi-power"></i><span>Log Out</span></a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>	
</nav>
<!-- /Top Menu Items -->