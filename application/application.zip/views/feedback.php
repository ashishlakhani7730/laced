<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include("header_include.php");
        ?>
    </head>

    <body>
        <!--Preloader-->
        <div class="preloader-it">
            <div class="la-anim-1"></div>
        </div>
        <!--/Preloader-->
        <div class="wrapper theme-1-active pimary-color-red">
            <?php
            include("header_body.php");
            ?>
            <?php
            include("header_body_side.php");
            ?>

            <!-- Main Content -->
            <div class="page-wrapper">
                <div class="container-fluid">

                    <!-- Title -->
                    <div class="row heading-bg">
                        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                            <h5 class="txt-dark">Feedback</h5>
                        </div>

                        <!-- Breadcrumb -->
                        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                            <ol class="breadcrumb">
                                <li><a href="#">About us</a></li>
                                <li class="active"><span>Feedback</span></li>
                            </ol>
                        </div>
                        <!-- /Breadcrumb -->

                    </div>
                    <!-- /Title -->
                    <div class="panel-wrapper collapse in">
                            <div class="panel-body">
                                <div class="table-wrap">
                                    <table id="example" class="table" data-sorting="true">
                                        <thead>
                                            <tr>
                                                <th>serial no</th>
                                                <th>User ProfilePic</th>
                                                <th>User Name</th> 
                                                <th>Feedback</th> 
                                                <th>Action</th>													
                                            </tr>
                                        </thead>
                                        <?php
                                        if (!empty($feedback)) {
                                            $cnt = 1;
                                            foreach ($feedback as $feed) {
                                                ?>
                                                <tr>
                                                    <td><?php echo $cnt++ ?></td>
                                                    <td><img class="user-img img-circle"  src="<?php echo base_url() ?>./Items/<?php echo $feed->User_ProfilePic ?>" alt="user" style="width: 50px; height: 50px;" /></td>
                                                    <td><?php echo $feed->User_Name; ?></td>
                                                    <td><?php echo $feed->feedback; ?></td>
                                                    <td> <button type="button" class="btn btn-info" > <a onclick="return confirm('Are you sure you want to delete this item?');" href="<?php echo site_url("Feedback/delete_data/$feed->Feedback_Id") ?>"> Delete</a></button>

                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        } else {
                                            echo "<tr><td colspan='4'>User Not Added Any Feedback!!</td></tr>";
                                        }
                                        ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    
                </div>
            </div>
        </div>

        <?php
        include("footer_include.php");
        ?>
    </body>
</html>
