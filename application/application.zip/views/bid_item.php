<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include("header_include.php");
        ?>
    </head>
    <body>
        <!--Preloader-->
        <div class="preloader-it">
            <div class="la-anim-1"></div>
        </div>
        <!--/Preloader-->
		<div class="wrapper theme-1-active pimary-color-red">
        <?php
        include("header_body.php");
        ?>
        <?php
        include("header_body_side.php");
        ?>
        <!-- Main Content -->

        <!-- Title -->
        <div class="page-wrapper">
            <div class="container-fluid">
                <!-- Title -->
                <div class="row heading-bg">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h5 class="txt-dark">Biding Product</h5>
                    </div>
                    <!-- Breadcrumb -->
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><a href="<?php echo base_url().'home/index'; ?>">Dashboard</a></li>
                            <li><a href="#"><span>Biding Product List</span></a></li>
                        </ol>
                    </div>
                    <!-- /Breadcrumb -->
                </div>
				<?php if(validation_errors()) { ?>
								<div id="validationerror" class="alert alert-info alert-dismissable">
									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><?php echo validation_errors(); ?>
								</div>						
				<?php } ?>
                <div id="successMessage" class="alert alert-success alert-dismissable">
											<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><?php echo $this->session->flashdata('message'); ?> 
				</div>
				<div id="failMessage" class="alert alert-info alert-dismissable">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><?php echo $this->session->flashdata('fail_message'); ?>
				</div>


				<div class="row">
					<div class="col-sm-12">
						<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<h6 class="panel-title txt-dark">Biding Product</h6>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body">									
									<div id="moreresponsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
											<div class="modal-dialog">
												<div class="modal-content">
													<div class="modal-header">
														<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
														<h5 class="modal-title">More Detail in product</h5>
													</div>
													<div class="modal-body">
														<div id="moremodfailMessage" class="alert alert-info alert-dismissable">
															<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><div id="moremodfMessage"></div>
														</div>
													</div>
													<div class="modal-footer">
														<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>									
													</div>
												</div>
											</div>
									</div>
									<div id="bidresponsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
											<div class="modal-dialog">
												<div class="modal-content">
													<div class="modal-header">
														<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
														<h5 class="modal-title">Auction Bidding list</h5>
													</div>
													<div id="bid-body" class="modal-body">
														<div id="bidmodfailMessage" class="alert alert-info alert-dismissable">
															<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><div id="bidmodfMessage"></div>
														</div>
													</div>
													<div class="modal-footer">
														<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>									
													</div>
												</div>
											</div>
									</div>
									<div class="table-wrap">
										<div class="table-responsive">
											<table id="datable_1" class="table table-hover display  pb-30" >
												<thead>
                                                    <tr>
                                                        <th>serial no</th>
                                                        <th>Item Name</th>
                                                        <th>Item FrontPicture</th>                                                   
                                                        <th>Item NormalPrice</th>
                                                        <th>Item MarketPrice</th>
														<th>Start Date</th>
														<th>End Date</th>
                                                        <th>More Detail</th>
														<th>View Bid List</th>
                                                    </tr>
                                                </thead>
                                                <?php
												if($bidlist)
												{
													$cnt = 1;
													foreach ($bidlist as $item) {
														?>
														<tr>
															<td><?php echo $cnt++ ?></td>
															<td><?php echo $item->Item_Name ?></td>
															<td><img src="<?php echo base_url() ?>./Items/<?php echo $item->Item_FrontPicture ?>" height="50" width="50"></td>
															
															<td><?php echo $item->Item_NormalPrice ?></td>
															<td><?php echo $item->Item_MarketPrice ?></td>
															<td><?php echo $item->startdateampm ?></td>
															<td><?php echo $item->endddateampm ?></td>
															<td><button type="button" class="btn btn-primary" onclick="moredetail(<?php echo $item->Item_Id; ?>)" data-toggle="modal" data-target="#moreresponsive-modal" data-whatever="@mdo">More</button></td>
															<td><button type="button" class="btn  btn-success" onclick="getbiding(<?php echo $item->Item_Id; ?>)" data-toggle="modal" data-target="#bidresponsive-modal" data-whatever="@mdo"><i class="fa fa-gavel mr-20"></i>Biding</button></td>
														</tr>
														<?php
													}
												}
												else
												{
													echo "<tr><td colspan='12'>No any Product Found On Bid</td></tr>";
												}
                                                ?>
                                            </table>
										</div>
									</div>
								</div>
							</div>
						</div>	
					</div>
				</div>            
                </div>
            </div>
            <!-- /Breadcrumb -->
        </div>
        <!-- /Title -->
        <!-- Footer -->
        <footer class="footer container-fluid pl-30 pr-30">
            <div class="row">
                <div class="col-sm-12">
                    
                </div>
            </div>
        </footer>
        <!-- /Footer -->
    </div>
</div>
<?php
include("footer_include.php");
?>
<script>
	
	var htmls = '';
	function moredetail(itemid)
	{
		$.ajax({
				url: '<?php echo site_url('item/moredetails') ?> ',
				type: 'post',
				dataType: 'json',
				data: {item_id:itemid},
				success: function(json) {
					
					if(json.code == 1)
					{
							$(".modal-body").empty();
							htmls = "<div class='row'><div class='col-sm-12'>";
							htmls += "<table width='100%'><tr><td style='vertical-align: middle'><strong>Item front picture - </strong></td><td><img src='<?php echo base_url().'Items/'; ?>"+json.data[0].Item_FrontPicture+"' height='100' width='100'></td></tr>";
							htmls += "<tr><td style='vertical-align: middle'><strong>Item back picture - </strong></td><td><img src='<?php echo base_url().'Items/'; ?>"+json.data[0].Item_BackPicture+"' height='100' width='100'></td></tr>";		
							htmls += "<tr><td style='vertical-align: middle'><strong>Item side picture - </strong></td><td><img src='<?php echo base_url().'Items/'; ?>"+json.data[0].Item_SidePicture+"' height='100' width='100'></td></tr>";		
							htmls +="<tr><td><strong>Item condition - </strong></td><td>"+json.data[0].Item_Condition +"</td></tr>";//Item_Condition Item_Size Item_Availability Item_Brand Item_NormalPrice Item_MarketPrice Item_FrontPicture Item_BackPicture Item_SidePicture
							htmls +="<tr><td><strong>Item size - </strong></td><td>"+json.data[0].Item_Size +"</td></tr>";
							htmls +="<tr><td><strong>Item color - </strong></td><td>"+json.data[0].Item_Availability +"</td></tr>";
							htmls +="<tr><td><strong>Item brand - </strong></td><td>"+json.data[0].Brand_Name +"</td></tr>";
							htmls +="<tr><td><strong>Item normal price - </strong></td><td>"+json.data[0].Item_NormalPrice +"</td></tr>";
							htmls +="<tr><td><strong>Item market price - </strong></td><td>"+json.data[0].Item_MarketPrice +"</td></tr>";
							if(json.data[0].startdateampm == null)
							{
								htmls +="<tr><td><strong>Auction Starting date - </strong></td><td>Not Set</td></tr>";	
							}
							else
							{
								htmls +="<tr><td><strong>Auction Starting date - </strong></td><td>"+json.data[0].startdateampm +"</td></tr>";
							}

							if(json.data[0].endddateampm == null)
							{
								htmls +="<tr><td><strong>Auction Ending date - </strong></td><td>Not Set</td></tr>";
							}
							else
							{
								htmls +="<tr><td><strong>Auction Ending date - </strong></td><td>"+json.data[0].endddateampm +"</td></tr>";
							}
							htmls += "<table>";
							htmls += "</div></div>";
							$(".modal-body").html(htmls);
					}
					else if(json.code == 0)
					{
						$("#moremodfMessage").html('<strong>'+json.message+'</strong>');
						$("#moremodfailMessage").show();
						setTimeout(function(){
							$("#moremodfailMessage").hide();
						}, 8000);
					}
				}
			});
	}
	
	function getbiding(itemid)
	{
		$.ajax({
				url: '<?php echo site_url('bid/bidlist') ?> ',
				type: 'post',
				dataType: 'json',
				data: {item_id:itemid},
				success: function(json) {
					
					if(json.code == 1)
					{
							$("#bid-body").empty();
							htmls = "<div class='row'><div class='col-sm-12'>";
							htmls += "<table width='100%'>";
							htmls += "<th>User</th><th>Bid Price</th><th>Winner</th>";	
							
							for(var dt=0;dt<json.datas.length;dt++)
							{
								if(json.datas[dt].User_ProfilePic == '' || json.datas[dt].User_ProfilePic == null) 
								{
									htmls += "<tr><tr><td><img src='<?php echo base_url().'Items/2078405789cc7e5c03cc4997106747cb688fefcdef5b0febbabdef2.png'; ?>' height='30' width='30'><span style='vertical-align: middle'>"+json.datas[dt].User_Name+"</span></td><td>"+json.datas[dt].Bid_Price+"</td>";
									if(json.datas[dt].Winner == 0)
									{
										htmls += "<td>NO</td>";
									}
									else
									{
										htmls += "<td>Yes</td>";
									}
									htmls += "</tr>";		
								}
								else
								{
									htmls += "<tr><tr><td><img src='<?php echo base_url().'Items/'; ?>"+json.datas[dt].User_ProfilePic+"' height='30' width='30'><span style='vertical-align: middle'>"+json.datas[dt].User_Name+"</span></td><td>"+json.datas[dt].Bid_Price+"</td>";	
									if(json.datas[dt].Winner == 0)
									{
										htmls += "<td>NO</td>";
									}
									else
									{
										htmls += "<td>Yes</td>";
									}
									htmls += "</tr>";
								}
							}
							
							htmls += "<table>";
							htmls += "</div></div>";
							
							$("#bid-body").html(htmls);
					}
					else if(json.code == 0)
					{
						$("#bidmodfMessage").html('<strong>'+json.message+'</strong>');
						$("#bidmodfailMessage").show();
						setTimeout(function(){
							$("#bidmodfailMessage").hide();
						}, 8000);
					}
				}
			});
	}
	
	<?php if(validation_errors()) { ?>
	setTimeout(function() {
				$('#validationerror').fadeOut('slow');
            }, 10000);
	<?php } ?>
	<?php if(empty($this->session->flashdata('message'))) { ?>
			$('#successMessage').hide();
	<?php } else { ?>
			setTimeout(function() {
				$('#successMessage').fadeOut('slow');
            }, 5000);
	<?php } ?>
	
	<?php if(empty($this->session->flashdata('fail_message'))) { ?>
			$('#failMessage').hide();
	<?php } else { ?>
			setTimeout(function() {
				$('#failMessage').fadeOut('slow');
            }, 5000);
	<?php } ?>
	
</script>
</body>
</html>
