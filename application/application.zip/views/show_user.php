<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include("header_include.php");
        ?>
    </head>
    <body>
        <!--Preloader-->
        <div class="preloader-it">
            <div class="la-anim-1"></div>
        </div>
        <!--/Preloader-->
		<div class="wrapper theme-1-active pimary-color-red">
        <?php
        include("header_body.php");
        ?>
        <?php
        include("header_body_side.php");
        ?>
        <!-- Main Content -->
        <!-- Title -->
        <div class="page-wrapper">
            <div class="container-fluid">
                <!-- Title -->
                <div class="row heading-bg">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h5 class="txt-dark">User Detail</h5>
                    </div>
                    
                    <!-- /Breadcrumb -->
                </div>

                <!-- Row -->
                <?php if(validation_errors()) { ?>
				<div id="validationerror" class="alert alert-info alert-dismissable">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><?php echo validation_errors(); ?>
				</div>						
				<?php } ?>
				<div id="successMessage" class="alert alert-success alert-dismissable">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><?php echo $this->session->flashdata('message'); ?> 
				</div>
				<div id="failMessage" class="alert alert-info alert-dismissable">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><?php echo $this->session->flashdata('fail_message'); ?>
				</div>

                <div class="row">
                    <div class="col-sm-12">
                        <div class="panel panel-default card-view">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h6 class="panel-title txt-dark"></h6>

                                </div>
                               
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-wrapper collapse in">
                                <div class="panel-body">
                                    <div id="responsive-modal-verify" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                        <h5 class="modal-title">Verify User</h5>
                                                    </div>
                                                    <div id="udetail" class="modal-body">
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                    <div class="table-wrap">
										<div class="table-responsive">
											<table id="datable_1" class="table table-hover display  pb-30" >
                                            <thead>
                                                <tr>
                                                    <th>serial no</th>
                                                    <th>User ProfilePic</th>
                                                    <th>User Name</th>
                                                    <th>User Email</th>
                                                    <th>User Address</th>
                                                    <th>User Phone</th>
                                                    <th>User Status</th>
                                                    <th>Verify User</th>
                                                    <th>created</th> 
                                                    <th>action</th>
                                                </tr>
                                            </thead>
                                            <?php
                                            $cnt = 1;
                                            foreach ($user_list as $user) {
                                                ?>
                                                <tr>
                                                    <td><?php echo $cnt++ ?></td>
													<?php if($user->User_ProfilePic == '' || $user->User_ProfilePic == 'null') { ?>
													<td><img src="<?php echo base_url().'Items/2078405789cc7e5c03cc4997106747cb688fefcdef5b0febbabdef2.png'; ?>" height="50" width="50"></td>
													<?php } else { ?>
                                                    <td><img src="<?php echo base_url() ?>./Items/<?php echo $user->User_ProfilePic ?>" height="50" width="50"></td>
												    <?php } ?>
													<td><?php echo $user->User_Name ?></td>
                                                    <td><?php echo $user->User_Email ?></td>
                                                    <td><?php echo $user->User_Address ?></td>
                                                    <td><?php echo $user->User_Phone ?></td>
                                                    
                                                    <td><?php
                                                        $flag = $user->User_Status;
                                                        if ($flag == '1') {
                                                            ?>

                                                    <li class="glyphicon glyphicon-ok" style="color: green"></li>
                                                    <?php
                                                }
                                                ?>
                                                <?php
                                                if ($flag == '0') {
                                                    ?>
                                                    <li class="glyphicon glyphicon-remove" style="color: red"></li>
                                                    <?php
                                                }
                                                ?>
                                                </td>
                                                <?php if($user->User_verified == 1) { ?>
                                                    <td>
                                                    <li class="glyphicon glyphicon-ok" style="color: green"></li>
                                                    </td>
                                                <?php } else { ?>
                                                <td>
                                                    <button type="button" class="btn btn-primary " onclick="getviewverifyuserdetail(<?php echo $user->User_Id; ?>)" data-toggle="modal" data-target="#responsive-modal-verify" data-whatever="@mdo">verify</button>
                                                </td>
                                            <?php } ?>
                                                <td><?php echo $user->created ?></td>                            
                                                <td><div class="input-group-btn">
                                                        <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                                                        <ul class="dropdown-menu">
                                                            <li><a href="<?php echo site_url("user/delete_data/$user->User_Id") ?>"><span class="fa fa-trash-o"> &nbsp;    Delete</span></a></li>
                                                            <?php
                                                            if ($flag == '1') {
                                                                ?>
                                                            <li><a href="<?php echo site_url("user/deactive_data/$user->User_Id") ?>"><span class="glyphicon glyphicon-remove" style="color: red"> </span>&nbsp; Deactive</a></li>
                                                                <?php
                                                            }
                                                            ?>
                                                            <?php
                                                            if ($flag == '0') {
                                                                ?>
                                                                <li><a href="<?php echo site_url("user/active_data/$user->User_Id") ?>"><span class="glyphicon glyphicon-ok" style="color: green"> </span>&nbsp; Active</a></li>
                                                                <?php
                                                            }
                                                            ?>
                                                        </ul>
                                                    </div>  
                                                </td>
                                                </tr>
                                                <?php
                                            }
                                            ?>
                                        </table>
										</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /Breadcrumb -->
        </div>
        <!-- /Title -->

        <!-- Footer -->
        <footer class="footer container-fluid pl-30 pr-30">
            <div class="row">
                <div class="col-sm-12">
                    
                </div>
            </div>
        </footer>
        <!-- /Footer -->
    </div>
</div>
<?php
include("footer_include.php");
?>
<script>

   

    function getviewverifyuserdetail(userid)
    {
        $.ajax({
                url: '<?php echo site_url('user/getverifyuserdetail') ?> ',
                type: 'post',
                dataType: 'json',
                data: {User_id:userid},
                success: function(json) {
                     $("#udetail").empty();
                    if(json)
                    {
                            htmls = '<div id="marketsuccessMessage" class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><div id="marketMessage"></div></div><div id="marketfailMessage" class="alert alert-info alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><div id="marketfMessage"></div></div>';

                            htmls += "<div class='row'><div class='col-sm-12'><table width='100%'>";
                            if(json.creditcarddetail == 1)
                            {
                                 htmls +="<tr><td><strong>User Added their Creadit Card - </strong></td><td>YES</td></tr>";
                            }
                            else
                            {
                                htmls +="<tr><td><strong>User Added their Creadit Card - </strong></td><td>NO</td></tr>";
                            }

                            if(json.bankdetail == 1)
                            {
                                 htmls +="<tr><td><strong>User Added their Bank Detail - </strong></td><td>YES</td></tr>";
                            }
                            else
                            {
                               htmls +="<tr><td><strong>User Added their Bank Detail - </strong></td><td>NO</td></tr>";
                            }

                            if(json.creditcarddetail == 1 && json.bankdetail == 1)
                            {
                                htmls +="<tr><td colspan='2' style='text-align:center'><button onclick='verifieded("+userid+")' type='button' class='btn btn-success'>Verified This User</button></tr></td>";
                            }
                           
                            htmls += "<table>";
                            htmls += "</div></div>";
                            $("#udetail").html(htmls);

                             $("#marketsuccessMessage").hide();
                             $("#marketfailMessage").hide();
                    }
                }
            });
    }


    function verifieded(user_id)
    {
        //console.log(user_id);

         $.ajax({
                url: '<?php echo site_url('user/verifyuser') ?> ',
                type: 'post',
                dataType: 'json',
                data: {USERID:user_id},
                success: function(json) {
                    if(json.code == 1)
                    {
                        $("#marketMessage").html('<strong>'+json.message+'</strong>');
                        $("#marketsuccessMessage").show();
                        setTimeout(function(){
                            $("#marketsuccessMessage").hide(); 
                            $('#responsive-modal-verify').modal('hide');
                             window.location.href="<?php echo site_url('user') ?>";
                        }, 5000);

                    }
                    else if(json.code == 0)
                    {
                        $("#marketfMessage").html('<strong>'+json.message+'</strong>');
                        $("#marketfailMessage").show();
                        setTimeout(function(){
                            $("#marketfailMessage").hide();
                        }, 8000);
                    }
                }
        });
    }

	<?php if(validation_errors()) { ?>
	setTimeout(function() {
				$('#validationerror').fadeOut('slow');
            }, 10000);
	<?php } ?>
	<?php if(empty($this->session->flashdata('message'))) { ?>
			$('#successMessage').hide();
	<?php } else { ?>
			setTimeout(function() {
				$('#successMessage').fadeOut('slow');
            }, 5000);
	<?php } ?>
	
	<?php if(empty($this->session->flashdata('fail_message'))) { ?>
			$('#failMessage').hide();
	<?php } else { ?>
			setTimeout(function() {
				$('#failMessage').fadeOut('slow');
            }, 5000);
	<?php } ?>
	</script>
</body>
</html>