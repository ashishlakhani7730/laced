	<meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <title>Laced Admin</title>
        <meta name="description" content="laced admin" />
        <meta name="keywords" content="laced admin" />

        <!-- Favicon -->
        <link rel="shortcut icon" href="favicon.ico">
        <link rel="icon" href="<?php echo base_url(); ?>Items/adminlogo.png" type="image/x-icon">

        <!-- Morris Charts CSS -->
        <link href="<?php echo base_url(); ?>assets/vendors/bower_components/morris.js/morris.css" rel="stylesheet" type="text/css"/>

        <!-- Data table CSS -->
        <link href="<?php echo base_url(); ?>assets/vendors/bower_components/datatables/media/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>

        <link href="<?php echo base_url(); ?>assets/vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url(); ?>assets/vendors/bower_components/swal2/sweetalert2.min.css" rel="stylesheet" type="text/css">
 <link href="<?php echo base_url(); ?>assets/vendors/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" type="text/css"/>
        <!-- Custom CSS -->
        <link href="<?php echo base_url(); ?>assets/dist/css/style.css" rel="stylesheet" type="text/css">
        
        <!-- Bootstrap Datetimepicker CSS -->
		<link href="<?php echo base_url(); ?>assets/vendors/bower_components/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css"/>
			
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/bower_components/bootstrap3-wysihtml5-bower/dist/bootstrap3-wysihtml5.css" />

		<!-- switchery CSS -->
		<link href="<?php echo base_url(); ?>assets/vendors/bower_components/switchery/dist/switchery.min.css" rel="stylesheet" type="text/css"/>