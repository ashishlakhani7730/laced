<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include("header_include.php");
        ?>
    </head>

    <body>
        <!--Preloader-->
        <div class="preloader-it">
            <div class="la-anim-1"></div>
        </div>
        <!--/Preloader-->
	<div class="wrapper theme-1-active pimary-color-red">
        <?php
        include("header_body.php");
        ?>
        <?php
        include("header_body_side.php");
        ?>
        			
			<!-- Main Content -->
			<div class="page-wrapper">
				<div class="container-fluid">
					
					<!-- Title -->
					<div class="row heading-bg">
						<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
							<h5 class="txt-dark">RateUS</h5>
						</div>
					
						<!-- Breadcrumb -->
						<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
							<ol class="breadcrumb">
								<li><a href="#">About us</a></li>
								<li class="active"><span>Rating List</span></li>
							</ol>
						</div>
						<!-- /Breadcrumb -->
					
					</div>
					<!-- /Title -->
					<?php if(isset($rating)) { ?>
					<?php foreach($rating as $rate){ ?>
					
					<div class="row">
					<div class="col-md-12">
							<div class="panel panel-default card-view">
								<div class="panel-heading">
									<div class="text-center">
										<div class="chat-data">
											<img class="user-img img-circle"  src="<?php echo base_url() ?>./Items/<?php echo $rate->User_ProfilePic ?>" alt="user"/>
											<div class="user-data">
												<h6 class="panel-title txt-dark"><?php echo $rate->User_Name; ?></h6>									
											</div>								
											<div class="clearfix"></div>
										</div>										
									</div>
									<div class="clearfix"></div>
								</div>
								<div  class="panel-wrapper collapse in">
									<div  class="panel-body">
										<blockquote>Rating is - <?php for($i=0;$i<$rate->ratingnumber;$i++) { ?><span class="fa fa-star"></span><?php } ?><?php echo "   ".$rate->ratingnumber." - Star"?></blockquote>
									</div>
								</div>
							</div>
					</div>
					</div>
					<?php } } else { ?>
						<div class="row">
						<div class="col-md-12">
							User Not Added Any Feedback!
						</div>
						</div>
					<?php } ?>
				</div>
			</div>
    </div>

<?php
include("footer_include.php");
?>
</body>
</html>
