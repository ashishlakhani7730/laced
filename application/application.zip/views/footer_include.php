<script src="<?php echo base_url(); ?>assets/vendors/bower_components/jquery/dist/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<script src="<?php echo base_url(); ?>assets/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/js/dataTables-data.js"></script>

<!-- modal -->
<script src="<?php echo base_url(); ?>assets/dist/js/modal-data.js"></script>

<!-- wysuhtml5 Plugin JavaScript -->
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/wysihtml5x/dist/wysihtml5x.min.js"></script>
		
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/bootstrap3-wysihtml5-bower/dist/bootstrap3-wysihtml5.all.js"></script>
		
<!-- Bootstrap Wysuhtml5 Init JavaScript -->
<script src="<?php echo base_url(); ?>assets/dist/js/bootstrap-wysuhtml5-data.js"></script>
		
<!-- Slimscroll JavaScript -->
<script src="<?php echo base_url(); ?>assets/dist/js/jquery.slimscroll.js"></script>

<!-- simpleWeather JavaScript -->
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/moment/min/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/simpleWeather/jquery.simpleWeather.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/js/simpleweather-data.js"></script>

<!-- Progressbar Animation JavaScript -->
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/waypoints/lib/jquery.waypoints.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/jquery.counterup/jquery.counterup.min.js"></script>

<!-- Fancy Dropdown JS -->
<script src="<?php echo base_url(); ?>assets/dist/js/dropdown-bootstrap-extended.js"></script>

<!-- Sparkline JavaScript -->
<script src="<?php echo base_url(); ?>assets/vendors/jquery.sparkline/dist/jquery.sparkline.min.js"></script>

<!-- Owl JavaScript -->
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>

<!-- ChartJS JavaScript -->
<script src="<?php echo base_url(); ?>assets/vendors/chart.js/Chart.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/raphael/raphael.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/morris.js/morris.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.js"></script>

<!-- Switchery JavaScript -->
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/switchery/dist/switchery.min.js"></script>

<!-- Init JavaScript -->
<script src="<?php echo base_url(); ?>assets/dist/js/init.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/js/dashboard-data.js"></script>
<!-- Bootstrap Datetimepicker JavaScript -->
<script type="text/javascript" src="<?php echo base_url() ?>assets/vendors/bower_components/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>

<!-- Data table JavaScript -->
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/bower_components/swal2/sweetalert2.min.js"></script>
<script>


$("#notify").click(function(){
    $.ajax({
                url: '<?php echo site_url('user/notification') ?> ',
                type: 'post',
                dataType: 'json',
                success: function(json) {
                    if(json.code == 1)
                    {
                         $(".top-nav-icon-badge").text('0');
                    }
                    else
                    {
                        console.log('somthing went to wrong');
                    }
                }
            });
});

    $(function () {
        window.setTimeout(function ()
        {
            $(".alert").fadeTo(500, 0).slideUp(500, function ()
            {
                $(this).remove();
            });
        }, 2000);

    });
</script>

<script>
    jQuery(document).ready(function()
    {
       $("#datable_1").DataTable(); 
    });
</script>
<!--<script>
    var date=new Date();
    date.setDate(date.getDate());
    $('#datetimepicker1').click(function()
    {
        $(#dob).datepicker(
                {
                    formate:'';
            autofocus:'true';
                });
    });
</script>-->